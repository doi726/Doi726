require("dotenv").config();
const { connectToWhatsApp } = require("./services/whatsapp");
require("./utils/cleaner").start();

connectToWhatsApp();
