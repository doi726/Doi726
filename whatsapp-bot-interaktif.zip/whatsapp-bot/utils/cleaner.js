const cron = require("node-cron");
const mongoose = require("mongoose");
const User = require("../models/User");

function start() {
    mongoose.connect(process.env.MONGO_URI);
    cron.schedule("0 0 * * *", async () => {
        console.log("Menghapus data pengguna lama...");
        await User.deleteMany({});
    });
}

module.exports = { start };
