const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require("@whiskeysockets/baileys");
const { MongoClient } = require("mongodb");
const path = require("path");
const messageHandler = require("../handlers/messageHandler");

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(process.env.SESSION_FOLDER || "session");
    const { version } = await fetchLatestBaileysVersion();
    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: true
    });

    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("messages.upsert", async ({ messages }) => {
        if (!messages[0]?.message) return;
        await messageHandler(sock, messages[0]);
    });

    console.log("WhatsApp bot is running.");
}

module.exports = { connectToWhatsApp };
