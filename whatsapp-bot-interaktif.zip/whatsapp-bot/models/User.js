const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    jid: { type: String, required: true, unique: true },
    chatgpt: String,
    serpapi: String,
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("User", userSchema);
