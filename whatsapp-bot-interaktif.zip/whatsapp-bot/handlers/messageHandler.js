const axios = require("axios");
const fs = require("fs");
const path = require("path");
const User = require("../models/User");

async function messageHandler(sock, msg) {
    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
    const buttonResponse = msg.message.buttonsResponseMessage?.selectedButtonId;

    if (!text && !buttonResponse) return;

    let user = await User.findOne({ jid: from });
    if (!user) {
        user = await User.create({ jid: from });
        await sock.sendMessage(from, { text: "Selamat datang! Kirimkan API Key ChatGPT & SerpAPI Anda:
chatgpt:<key>
serpapi:<key>" });
        return;
    }

    if (text?.startsWith("chatgpt:")) {
        user.chatgpt = text.split("chatgpt:")[1].trim();
        await user.save();
        await sock.sendMessage(from, { text: "API Key ChatGPT disimpan." });
        return;
    }

    if (text?.startsWith("serpapi:")) {
        user.serpapi = text.split("serpapi:")[1].trim();
        await user.save();
        await sock.sendMessage(from, { text: "API Key SerpAPI disimpan." });
        return;
    }

    // MENU INTERAKTIF
    if (text === "/menu") {
        await sock.sendMessage(from, {
            text: "Silakan pilih menu:",
            buttons: [
                { buttonId: "btn_chatgpt", buttonText: { displayText: "Tanya ChatGPT" }, type: 1 },
                { buttonId: "btn_gambar", buttonText: { displayText: "Minta Gambar" }, type: 1 },
                { buttonId: "btn_serpapi", buttonText: { displayText: "Cari Info" }, type: 1 }
            ],
            footer: "Bot WhatsApp Interaktif"
        });
        return;
    }

    // BUTTON HANDLER
    if (buttonResponse) {
        if (buttonResponse === "btn_gambar") {
            const imgPath = path.join(__dirname, "../media/sample.jpg");
            await sock.sendMessage(from, {
                image: fs.readFileSync(imgPath),
                caption: "Ini gambar yang kamu minta."
            });
        } else if (buttonResponse === "btn_serpapi") {
            if (!user.serpapi) return sock.sendMessage(from, { text: "Masukkan API Key SerpAPI dulu." });
            const result = await axios.get(`https://serpapi.com/search.json?q=OpenAI&api_key=${user.serpapi}`);
            const topResult = result.data.organic_results?.[0]?.title || "Tidak ada hasil.";
            await sock.sendMessage(from, { text: `Hasil teratas pencarian: ${topResult}` });
        } else if (buttonResponse === "btn_chatgpt") {
            await sock.sendMessage(from, { text: "Silakan kirim pertanyaan Anda." });
        }
        return;
    }

    if (!user.chatgpt) {
        await sock.sendMessage(from, { text: "Silakan masukkan API Key ChatGPT Anda terlebih dahulu." });
        return;
    }

    try {
        const response = await axios.post("https://api.openai.com/v1/chat/completions", {
            model: "gpt-4",
            messages: [{ role: "user", content: text }]
        }, {
            headers: { Authorization: `Bearer ${user.chatgpt}` }
        });

        const reply = response.data.choices[0].message.content;
        await sock.sendMessage(from, { text: reply });
    } catch (err) {
        await sock.sendMessage(from, { text: "Gagal memproses permintaan." });
    }
}

module.exports = messageHandler;
