const axios = require("axios");
const User = require("../models/User");

async function messageHandler(sock, msg) {
    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    if (!text) return;

    let user = await User.findOne({ jid: from });
    if (!user) {
        user = await User.create({ jid: from });
        await sock.sendMessage(from, { text: "Selamat datang! Kirimkan API Key ChatGPT & SerpAPI Anda dalam format:
chatgpt:<key>
serpapi:<key>" });
        return;
    }

    if (text.startsWith("chatgpt:")) {
        user.chatgpt = text.split("chatgpt:")[1].trim();
        await user.save();
        await sock.sendMessage(from, { text: "API Key ChatGPT disimpan." });
        return;
    }

    if (text.startsWith("serpapi:")) {
        user.serpapi = text.split("serpapi:")[1].trim();
        await user.save();
        await sock.sendMessage(from, { text: "API Key SerpAPI disimpan." });
        return;
    }

    if (!user.chatgpt) {
        await sock.sendMessage(from, { text: "Silakan masukkan API Key ChatGPT Anda terlebih dahulu." });
        return;
    }

    try {
        const response = await axios.post("https://api.openai.com/v1/chat/completions", {
            model: "gpt-4",
            messages: [{ role: "user", content: text }]
        }, {
            headers: { Authorization: `Bearer ${user.chatgpt}` }
        });

        const reply = response.data.choices[0].message.content;
        await sock.sendMessage(from, { text: reply });
    } catch (err) {
        await sock.sendMessage(from, { text: "Gagal memproses permintaan." });
    }
}

module.exports = messageHandler;
